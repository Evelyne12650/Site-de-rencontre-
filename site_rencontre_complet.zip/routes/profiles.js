const express = require('express');
const router = express.Router();
const User = require('../models/User');

router.get('/', async (req, res) => {
  const users = await User.find({}, '-password');
  res.json(users);
});

router.post('/like/:id', async (req, res) => {
  const { id } = req.params;
  const { likerId } = req.body;
  try {
    const user = await User.findById(likerId);
    if (!user.likes.includes(id)) {
      user.likes.push(id);
      await user.save();
    }
    res.json(user);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;
